<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>
	<body>
<?php
	$servername = "localhost"; 
	$username = "id4717797_ynt_db";
	$password = "ynt1001";
	$database = "id4717797_ynt";
	
	$nm =$_GET["nm"];
	$city =$_GET["ct"];
	$age=$_GET["age"];
	
//	$conn = mysqli_connect($servername, $username, $password, $database);
	$conn = mysqli_connect("localhost","id4717797_ynt_db","ynt1001","id4717797_ynt");
	$db_sel = mysqli_select_db($conn,"id4717797_ynt");
//		if(!$db_sel)
//		{
//			die("database is not selected");
//		}
//		echo "Database is selected"
	mysqli_query($conn,"insert into YNT_Contact values('$nm','$city','$age')");

//	if (!$conn) {
//    die("Connection failed: " . mysqli_connect_error());
//	}
//	echo "Connected successfully";
?>

</body>
</html>